from code.evaluation import binary_plots, multiclass_plots, regression_plots
import numpy as np
import os

class Plot_ML_data:
    def __init__(self, path_to_evaluation, tasks, list_of_antibiotics=None):
        self.path_to_evaluation = path_to_evaluation
        self.tasks = tasks
        self.list_of_antibiotics = list_of_antibiotics
        self.list_files_for_plot = ('y_test.npy', 'y_pred.npy', 'y_prob.npy', 'best_params.json')

        if 'binary' in self.tasks:
            self.plot_binary_data()
        if 'multi' in self.tasks or 'full' in self.tasks:
            self.plot_multi_data()
        if 'regression' in self.tasks:
            if 'milk' in self.list_of_antibiotics:
                self.list_of_antibiotics.remove('milk')
            self.plot_regression()
        if len(self.tasks) == 0:
            print('No data for plot')

    def plot_binary_data(self):
        path_to_folder = os.path.join(self.path_to_evaluation, 'binary')
        path_to_binary_json = os.path.join(self.path_to_evaluation, 'binary', self.list_files_for_plot[3])
        path_to_files = (
            os.path.join(path_to_folder, self.list_files_for_plot[0]),
            os.path.join(path_to_folder, self.list_files_for_plot[1]),
            os.path.join(path_to_folder, self.list_files_for_plot[2])
        )
        if self.path_to_evaluation.split(os.sep)[-1].startswith('catboost'):
            binary_plots.plot_data_classification(path_to_binary_json)
        binary_plots.plot_classification_subplot(path_to_files[0],
                                                 path_to_files[1],
                                                 path_to_files[2],
                                                 path_to_folder)

    def plot_multi_data(self):
        tasks = ['multi', 'full']
        saved_tasks = []
        for task in tasks:
            if task in self.tasks:
                saved_tasks.append(task)

        if len(saved_tasks) == 0:
            print('No data for plot')

        for plot in saved_tasks:
            path_to_folder = os.path.join(self.path_to_evaluation, plot)
            path_to_multi_json = os.path.join(self.path_to_evaluation, plot, self.list_files_for_plot[3])
            path_to_files = (
                os.path.join(path_to_folder, self.list_files_for_plot[0]),
                os.path.join(path_to_folder, self.list_files_for_plot[1]),
                os.path.join(path_to_folder, self.list_files_for_plot[2])
            )
            if self.path_to_evaluation.split(os.sep)[-1].startswith('catboost'):
                multiclass_plots.plot_data_classification(path_to_multi_json)
            multiclass_plots.plot_classification_subplot(path_to_files[0],
                                                         path_to_files[1],
                                                         path_to_files[2],
                                                         path_to_folder)

    def plot_regression(self):
        for antibiotic in self.list_of_antibiotics:
            path_to_folder = os.path.join(self.path_to_evaluation, 'regression', antibiotic)
            y_test = np.load(os.path.join(path_to_folder, 'y_test.npy'), allow_pickle=True)
            y_pred = np.load(os.path.join(path_to_folder, 'y_pred.npy'), allow_pickle=True)
            regression_plots.plot_regression(y_test, y_pred, path_to_folder)
            regression_plots.plot_r2_score(y_test, y_pred, path_to_folder)