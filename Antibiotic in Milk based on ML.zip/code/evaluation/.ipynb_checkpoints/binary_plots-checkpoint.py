import scikitplot as skplt
import matplotlib.pyplot as plt
import os
import numpy as np
import json
from code.paths.paths import PATH_TO_EVALUATION






def plot_data_classification(path_to_file):
    f = open(path_to_file)
    data = json.load(f)
    f.close()
    list_keys = [i for i in data['cv_results'].keys()]
    '''
    First graph with train and test accuracy mean
    '''
    print(list_keys)
    X = data['cv_results'][list_keys[0]]
    Y = data['cv_results'][list_keys[3]]
    Y1 = data['cv_results'][list_keys[1]]
    LabesX = list_keys[0].lower().title()
    LabelY = ' '.join(list_keys[3].lower().split('-'))
    LabelY1 = ' '.join(list_keys[1].lower().split('-'))
    plt.plot(X, Y, label=LabelY)
    plt.plot(X, Y1, label=LabelY1)
    plt.title((LabelY.split(' ')[0] + ' ' + LabelY1.split(' ')[0] + ' and ' + LabelY.split(' ')[1] + ' ' + LabelY.split(
        ' ')[2]))
    plt.legend()
    plt.xlabel(LabesX)
    plt.ylabel(LabelY.split(' ')[1] + ' ' + LabelY.split(' ')[2])
    plt.tight_layout()
    plt.savefig((path_to_file[:-16] + '-'.join([LabelY.split(' ')[0], LabelY1.split(' ')[0], LabelY1.split(' ')[1],
                                                LabelY1.split(' ')[2]]) + '.svg'), format='svg', bbox_inches='tight')
    #plt.show()
    plt.close()

    '''
    Second graph with train and test accuracy std
    '''

    Y2 = data['cv_results'][list_keys[4]]
    Y3 = data['cv_results'][list_keys[2]]
    LabesY2 = ' '.join(list_keys[4].lower().split('-'))
    LabesY3 = ' '.join(list_keys[2].lower().split('-'))
    plt.plot(X, Y2, label=LabesY2)
    plt.plot(X, Y3, label=LabesY3)
    plt.title((LabesY2.split(' ')[0] + ' ' + LabesY3.split(' ')[0] + ' and ' + LabesY2.split(' ')[1] + ' ' +
               LabesY2.split(' ')[2]))
    plt.legend()
    plt.xlabel(LabesX)
    plt.ylabel(LabesY2.split(' ')[1] + ' ' + LabesY2.split(' ')[2])
    plt.tight_layout()
    plt.savefig((path_to_file[:-16] + '-'.join([LabesY2.split(' ')[0], LabesY3.split(' ')[0], LabesY3.split(' ')[1],
                                                LabesY3.split(' ')[2]]) + '.svg'), format='svg', bbox_inches='tight')
    #plt.show()
    plt.close()

    '''
    Third graph with train and test loss function mean
    '''

    Y4 = data['cv_results'][list_keys[7]]
    Y5 = data['cv_results'][list_keys[5]]
    LabesY4 = ' '.join(list_keys[7].lower().split('-'))
    LabesY5 = ' '.join(list_keys[5].lower().split('-'))
    plt.plot(X, Y4, label=LabesY4)
    plt.plot(X, Y5, label=LabesY5)
    plt.title((LabesY4.split(' ')[0] + ' ' + LabesY5.split(' ')[0] + ' and ' + LabesY4.split(' ')[1] + ' ' +
               LabesY4.split(' ')[2]))
    plt.legend()
    plt.xlabel(LabesX)
    plt.ylabel(LabesY4.split(' ')[1] + ' ' + LabesY4.split(' ')[2])
    plt.tight_layout()
    plt.savefig((path_to_file[:-16] + '-'.join([LabesY4.split(' ')[0], LabesY5.split(' ')[0], LabesY5.split(' ')[1],
                                                LabesY5.split(' ')[2]]) + '.svg'), format='svg', bbox_inches='tight')
    #plt.show()
    plt.close()

    '''
    Last graph with train and test losses function std
    '''

    Y6 = data['cv_results'][list_keys[8]]
    Y7 = data['cv_results'][list_keys[6]]
    LabesY6 = ' '.join(list_keys[8].lower().split('-'))
    LabesY7 = ' '.join(list_keys[6].lower().split('-'))
    plt.plot(X, Y6, label=LabesY6)
    plt.plot(X, Y7, label=LabesY7)
    plt.title((LabesY6.split(' ')[0] + ' ' + LabesY7.split(' ')[0] + ' and ' + LabesY6.split(' ')[1] + ' ' +
               LabesY6.split(' ')[2]))
    plt.legend()
    plt.xlabel(LabesX)
    plt.ylabel(LabesY6.split(' ')[1] + ' ' + LabesY6.split(' ')[2])
    plt.tight_layout()
    plt.savefig((path_to_file[:-16] + '-'.join([LabesY6.split(' ')[0], LabesY7.split(' ')[0], LabesY7.split(' ')[1],
                                                LabesY7.split(' ')[2]]) + '.svg'), format='svg', bbox_inches='tight')
    #plt.show()
    plt.close()

def plot_classification_subplot(y_test_path, y_pred_path, y_provas_path, savepath=None):
    y_test, y_pred, y_provas = np.load(y_test_path, allow_pickle=True), np.load(y_pred_path, allow_pickle=True), \
                               np.load(y_provas_path, allow_pickle=True)
    fig, axs = plt.subplots(3, 2, figsize=(13, 13))
    skplt.metrics.plot_confusion_matrix(y_test, y_pred, normalize=True, ax=axs[2, 1], text_fontsize='large')
    skplt.metrics.plot_roc(y_test, y_provas, ax=axs[0, 1], text_fontsize='large')
    skplt.metrics.plot_precision_recall(y_test, y_provas, ax=axs[1, 0], text_fontsize='large')
    skplt.metrics.plot_ks_statistic(y_test, y_provas, ax=axs[1, 1], text_fontsize='large')
    skplt.metrics.plot_cumulative_gain(y_test, y_provas, ax=axs[2, 0], text_fontsize='large')
    skplt.metrics.plot_lift_curve(y_test, y_provas, ax=axs[0, 0], text_fontsize='large')
    fig.suptitle('Binary classification subplot on test data', y=1, fontsize=20)
    plt.tight_layout()
    plt.savefig(os.path.join(savepath, 'classification_subplot.svg'), bbox_inches='tight', format='svg')
    #plt.show()
    plt.close()
    skplt.metrics.plot_confusion_matrix(y_test, y_pred, normalize=True, text_fontsize='large')
    plt.tight_layout()
    plt.savefig(os.path.join(savepath, 'confusion_matrix.svg'), format='svg', bbox_inches='tight')
    plt.close()
    skplt.metrics.plot_roc(y_test, y_provas, text_fontsize='large')
    plt.tight_layout()
    plt.savefig(os.path.join(savepath, 'roc.svg'), format='svg', bbox_inches='tight')
    plt.close()
    skplt.metrics.plot_precision_recall(y_test, y_provas, text_fontsize='large')
    plt.tight_layout()
    plt.savefig(os.path.join(savepath, 'prec_recall.svg'), format='svg', bbox_inches='tight')
    plt.close()
    skplt.metrics.plot_ks_statistic(y_test, y_provas, text_fontsize='large')
    plt.tight_layout()
    plt.savefig(os.path.join(savepath, 'ks_statistic.svg'), format='svg', bbox_inches='tight')
    plt.close()
    skplt.metrics.plot_cumulative_gain(y_test, y_provas, text_fontsize='large')
    plt.tight_layout()
    plt.savefig(os.path.join(savepath, 'cumulative_gain.svg'), format='svg', bbox_inches='tight')
    plt.close()
    skplt.metrics.plot_lift_curve(y_test, y_provas, text_fontsize='large')
    plt.tight_layout()
    plt.savefig(os.path.join(savepath, 'lift_curve.svg'), format='svg', bbox_inches='tight')
    plt.close()

if __name__ == '__main__':
    y_test = np.load(os.path.join(PATH_TO_EVALUATION, 'galacticum_new_data', 'caboost2022_03_23-09:28:59_AM',
                                  'binary', 'y_test.npy'), allow_pickle=True)
    y_pred = np.load(os.path.join(PATH_TO_EVALUATION, 'galacticum_new_data', 'caboost2022_03_23-09:28:59_AM',
                                  'binary', 'y_pred.npy'), allow_pickle=True)
    y_prob = np.load(os.path.join(PATH_TO_EVALUATION, 'galacticum_new_data', 'caboost2022_03_23-09:28:59_AM',
                                  'binary', 'y_prob.npy'), allow_pickle=True)

    best_params = os.path.join(PATH_TO_EVALUATION, 'galacticum_new_data', 'caboost2022_03_23-09:28:59_AM',
                                  'binary', 'best_params.json')

    plot_classification_subplot(y_test, y_pred, y_prob, savepath=os.path.join(PATH_TO_EVALUATION, 'galacticum_new_data', 'caboost2022_03_23-09:28:59_AM',
                                  'binary'))

    plot_data_classification(best_params)