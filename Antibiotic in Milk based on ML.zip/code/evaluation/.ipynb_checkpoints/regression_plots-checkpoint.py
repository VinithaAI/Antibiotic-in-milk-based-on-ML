from code.paths.paths import PATH_TO_EVALUATION
import matplotlib.pyplot as plt
import numpy as np
import os

def plot_regression(y_test, y_pred, savepath=None):
    plt.figure(dpi=75)
    plt.scatter(y_test, y_pred)
    plt.plot(y_test, y_test, color='red')
    plt.xlabel('Actual Scores')
    plt.ylabel('Estimated Scores')
    plt.title('Model: Actual vs Estimated Scores')
    plt.tight_layout()
    plt.savefig(os.path.join(savepath, 'regression_plot.svg'), format='svg', bbox_inches='tight')
    plt.close()

def plot_r2_score(y_test, pred, savepath=None):
    fig, ax = plt.subplots()
    plt.rcParams.update({'font.size': '12'})
    plt.title('R2 score')
    ax.scatter(pred, y_test, edgecolor=(0, 0, 1))
    ax.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], 'r--', lw=3)
    ax.set_xlabel('Predicted', fontsize=12)
    ax.set_ylabel('Actual', fontsize=12)
    plt.tick_params(axis='both', which='major', labelsize='12')
    plt.tight_layout()
    plt.savefig(os.path.join(savepath, 'R2_plot.svg'), format='svg', bbox_inches='tight')
    plt.close()

if __name__ == '__main__':
    y_test = np.load(os.path.join(PATH_TO_EVALUATION, 'galacticum_new_data', 'caboost2022_03_23-09:28:59_AM',
                                  'regression', 'cefazolin', 'y_test.npy'), allow_pickle=True)
    y_pred = np.load(os.path.join(PATH_TO_EVALUATION, 'galacticum_new_data', 'caboost2022_03_23-09:28:59_AM',
                                  'regression', 'cefazolin', 'y_pred.npy'), allow_pickle=True)

    plot_r2_score(y_test, y_pred)
    plot_regression(y_test, y_pred)