import os
import numpy as np
from tqdm import tqdm
import textwrap
import pandas as pd
import shutil

class Galacticum_Variables:
    def __init__(self, folder, normalize=False, tasks=['binary', 'multi']):
        self.folder = folder
        self.normalize = normalize
        self.save_folder = os.path.join(self.folder, 'prepared_data')
        self.tasks = tasks


class Galacticum(Galacticum_Variables):
    def __init__(self, folder, normalize=False, tasks=['binary', 'multi']):
        super(Galacticum, self).__init__(folder, normalize, tasks)
        if os.path.exists(self.save_folder):
            shutil.rmtree(self.save_folder)
            os.mkdir(self.save_folder)
        else:
            os.mkdir(self.save_folder)
        self.create_dataset()


    def create_dataset(self):
        self.list_of_csv_files = self._list_of_csv_files()
        self.all_tasks = self._create_tasks()
        self.list_of_antibiotics = self.__create_list_of_antibiotics()
        if os.path.exists(os.path.join(self.save_folder, 'metadata.txt')):
            os.remove(os.path.join(self.save_folder, 'metadata.txt'))
            open(os.path.join(self.save_folder, 'metadata.txt'), 'a').close()

        for task in self.all_tasks:
            if task == 'binary':
                with open(os.path.join(self.save_folder, 'metadata.txt'), 'w') as f:
                    size_of_X, size_of_y, x_save_path, y_save_path = self._create_binary_dataset()
                    f.write(textwrap.dedent(f"""Creating binary dataset
                    Path to save .npy files : {self.save_folder}


                    Size of X dataset: {size_of_X} features
                    Size of y dataset: {size_of_y} features

                    X_data saved in {x_save_path}
                    y_data saved in {y_save_path}


                    Binary classification dataset saved in {self.save_folder}
                    X_data:
                        ---{x_save_path}
                    y_data:
                        ---{y_save_path}
                        
                        
                        
                    """))
                    f.close()


            if task == 'multi':
                with open(os.path.join(self.save_folder, 'metadata.txt'), 'a') as f:
                    size_of_X, size_of_y, x_save_path, y_save_path = self._create_multi_dataset()

                    f.write(textwrap.dedent(f"""Creating multiclassification dataset
                    Path to save .npy files : {self.save_folder}


                    Size of X dataset: {size_of_X} features
                    Size of y dataset: {size_of_y} features

                    X_data saved in {x_save_path}
                    y_data saved in {y_save_path}


                    Multiclassification dataset saved in {self.save_folder}
                    X_data:
                        ---{x_save_path}
                    y_data:
                        ---{y_save_path}



                    """))
                    f.close()

            if task == 'full':
                with open(os.path.join(self.save_folder, 'metadata.txt'), 'a') as f:
                    size_of_X, size_of_y, x_save_path, y_save_path = self._create_full_dataset()
                    f.write(textwrap.dedent(f"""Creating multiclassification dataset with milk
                    Path to save .npy files : {self.save_folder}


                    Size of X dataset: {size_of_X} features
                    Size of y dataset: {size_of_y} features

                    X_data saved in {x_save_path}
                    y_data saved in {y_save_path}


                    Multiclassification dataset with milk saved in {self.save_folder}
                    X_data:
                        ---{x_save_path}
                    y_data:
                        ---{y_save_path}



                    """))
                    f.close()

            if task == 'regression':
                self._create_regression_dataset()

    def __create_list_of_antibiotics(self):
        listdir = os.listdir(self.folder)
        if 'prepared_data' in listdir:
            listdir.remove('prepared_data')
        return listdir

    def _list_of_csv_files(self):
        list_of_csv_files = []
        for root, dirs, files in os.walk(self.folder):
            for file in files:
                if file.endswith('_compound.csv'):
                    list_of_csv_files.append(os.path.join(root, file))
        return list_of_csv_files

    def _create_tasks(self):
        all_tasks = []
        if 'binary' in self.tasks:
            all_tasks.append('binary')
        if 'multi' in self.tasks:
            all_tasks.append('multi')
        if 'full' in self.tasks:
            all_tasks.append('full')
        if 'regression' in self.tasks:
            all_tasks.append('regression')

        return all_tasks

    def __read_current(self, path):
        df = pd.read_csv(path)
        list_columns = df.columns.values.tolist()
        cycles = int(len(np.array(df[list_columns[0]])) / 5200)
        for cycle in range(cycles):
            start_cycle = cycle * 5200
            end_cycle = start_cycle + 5200
            new_df = df.loc[start_cycle:end_cycle]
            if len(df[list_columns[0]].loc[start_cycle:end_cycle]) != 2600:
                new_df = new_df.drop(new_df.tail(1).index, inplace=False)
            return np.array(new_df[list_columns[0]])


    def _create_binary_dataset(self):
        print(textwrap.dedent(f"""
        Creating binary dataset
        Path to save .npy files : {self.save_folder}
        """))

        X_data_binary = []
        y_data_binary = []
        X_data_save_folder = os.path.join(self.save_folder, 'X_data_binary_classification.npy')
        y_data_save_folder = os.path.join(self.save_folder, 'y_data_binary_classification.npy')

        for path in tqdm(self.list_of_csv_files):
            print(path)
            if 'milk' in path.split(os.sep):
                current = self.__read_current(path)
                X_data_binary.append(current)
                y_data_binary.append(str('milk'))
            else:
                current = self.__read_current(path)
                X_data_binary.append(current)
                y_data_binary.append(str('antibiotic'))

        X_data_binary = np.array(X_data_binary)
        y_data_binary = np.array(y_data_binary).astype(str)
        np.save(X_data_save_folder, X_data_binary)
        np.save(y_data_save_folder, y_data_binary)
        print(textwrap.dedent(f"""
        Binary classification dataset saved in {self.save_folder}
        X_data:
            ---{os.path.join(self.save_folder, 'X_data_binary_classification.npy')}
        y_data:
            ---{os.path.join(self.save_folder, 'y_data_binary_classification.npy')}
        """))

        return len(X_data_binary), len(y_data_binary), X_data_save_folder, y_data_save_folder

    def _create_multi_dataset(self):
        print(textwrap.dedent(f"""
        Creating multiclass dataset
        Path to save .npy files: {self.save_folder}
        """))

        X_data_multi = []
        y_data_multi = []
        X_data_save_folder = os.path.join(self.save_folder, 'X_data_multi_classification.npy')
        y_data_save_folder = os.path.join(self.save_folder, 'y_data_multi_classification.npy')

        for path in tqdm(self.list_of_csv_files):
            if 'milk' in path.split(os.sep):
                pass
            else:
                current = self.__read_current(path)
                X_data_multi.append(current)
                for antibiotic in self.list_of_antibiotics:
                    if antibiotic in path.split(os.sep):
                        y_data_multi.append(str(antibiotic))
        X_data_multi = np.array(X_data_multi)
        y_data_multi = np.array(y_data_multi).astype(str)
        np.save(X_data_save_folder, X_data_multi)
        np.save(y_data_save_folder, y_data_multi)
        print(textwrap.dedent(f"""
        Multiclassification dataset saved in {self.save_folder}
        X_data: 
            ---{os.path.join(self.save_folder, 'X_data_multi_classification.npy')}
        y_data:
            ---{os.path.join(self.save_folder, 'y_data_multi_classification.npy')}
        """))
        return len(X_data_multi), len(y_data_multi), X_data_save_folder, y_data_save_folder

    def _create_full_dataset(self):
        print(textwrap.dedent(f"""
        Creating multiclass dataset with milk
        Path to save .npy files: {self.save_folder}
        """))

        X_data = []
        y_data = []
        X_data_save_folder = os.path.join(self.save_folder, 'X_data_full_classification.npy')
        y_data_save_folder = os.path.join(self.save_folder, 'y_data_full_classification.npy')

        for path in tqdm(self.list_of_csv_files):
            current = self.__read_current(path)
            X_data.append(current)
            for antibiotic in self.list_of_antibiotics:
                if antibiotic in path.split(os.sep):
                    y_data.append(str(antibiotic))
        X_data = np.array(X_data)
        y_data = np.array(y_data).astype(str)
        np.save(X_data_save_folder, X_data)
        np.save(y_data_save_folder, y_data)
        print(textwrap.dedent(f"""
        Multiclassification dataset saved in {self.save_folder}
        X_data:
            ---{os.path.join(self.save_folder, 'X_data_full_classification.npy')}
        y_data:
            ---{os.path.join(self.save_folder, 'y_data_full_classification.npy')}
        """))

        return len(X_data), len(y_data), X_data_save_folder, y_data_save_folder

    def _create_regression_dataset(self):
        print(textwrap.dedent(f"""
        Creating regression datasets
        Path to save .npy files: {self.save_folder}
        """))
        with open(os.path.join(self.save_folder, 'metadata.txt'), 'a') as f:
            f.write(textwrap.dedent(f"""
            Creating regression datasets
            Path to save .npy files: {self.save_folder}
            """))
            list_of_antibiotics = self.list_of_antibiotics.copy()
            list_of_antibiotics.remove('milk')
            for antibiotic in list_of_antibiotics:
                print(textwrap.dedent(f"""
                Creating dataset for regression
                Antibiotic: {antibiotic}
                """))
                f.write(textwrap.dedent(f"""
                Creating dataset for regression
                Antibiotic: {antibiotic}
                """))
                X_data = []
                y_data = []

                for path in tqdm(self.list_of_csv_files):
                    if antibiotic in path.split(os.sep):
                        current = self.__read_current(path)
                        X_data.append(current)
                        conc = float(path.split(os.sep)[-3].split('_')[-1][:-3])
                        y_data.append(conc)
                X_data = np.array(X_data)
                y_data = np.array(y_data)
                np.save(os.path.join(self.save_folder, f'X_data_{antibiotic}_regression.npy'), X_data)
                np.save(os.path.join(self.save_folder, f'y_data_{antibiotic}_regression.npy'), y_data)
                print(textwrap.dedent(f"""
                Regression dataset for {antibiotic} saved in {self.save_folder}
                
                X_data:
                    ---{os.path.join(self.save_folder, f'X_data_{antibiotic}_regression.npy')}
                y_data:
                    ---{os.path.join(self.save_folder, f'y_data_{antibiotic}_regression.npy')}
                """))
                f.write(textwrap.dedent(f"""
                Regression dataset for {antibiotic} saved in {self.save_folder}
                
                Size of X data for {antibiotic}: {len(X_data)} features
                Size of y data for {antibiotic}: {len(y_data)} features
                
                X_data:
                    ---{os.path.join(self.save_folder, f'X_data_{antibiotic}_regression.npy')}
                y_data:
                    ---{os.path.join(self.save_folder, f'y_data_{antibiotic}_regression.npy')}
                """))
            f.close()







