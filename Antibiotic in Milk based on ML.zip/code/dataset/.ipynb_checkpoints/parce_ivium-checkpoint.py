import os
import numpy as np
from tqdm import tqdm
import textwrap
import shutil

from code.paths.paths import PATH_TO_DATA


class Ivium_Variables:
    def __init__(self, folder, normalize=False, tasks=['binary', 'multi']):
        self.folder = folder
        self.normalize = normalize
        self.save_folder = os.path.join(self.folder, 'prepared_data')
        self.tasks = tasks


class Ivium(Ivium_Variables):
    def __init__(self, folder, normalize=False, tasks=['binary', 'multi']):
        super(Ivium, self).__init__(folder, normalize, tasks)
        if os.path.exists(self.save_folder):
            shutil.rmtree(self.save_folder)
            os.mkdir(self.save_folder)
        else:
            os.mkdir(self.save_folder)
        self.create_dataset()

    def create_dataset(self):
        self.list_of_csv_files = self._list_of_csv_files()
        self.all_tasks = self._create_tasks()
        self.list_of_antibiotics = self.__create_list_of_antibiotics()
        if os.path.exists(os.path.join(self.save_folder, 'metadata.txt')):
            os.remove(os.path.join(self.save_folder, 'metadata.txt'))
            open(os.path.join(self.save_folder, 'metadata.txt'), 'a').close()

        for task in self.all_tasks:
            if task == 'binary':
                with open(os.path.join(self.save_folder, 'metadata.txt'), 'w') as f:
                    size_of_X, size_of_y, x_save_path, y_save_path = self._create_binary_dataset()
                    f.write(textwrap.dedent(f"""Creating binary dataset
                    Path to save .npy files : {self.save_folder}


                    Size of X dataset: {size_of_X} features
                    Size of y dataset: {size_of_y} features

                    X_data saved in {x_save_path}
                    y_data saved in {y_save_path}


                    Binary classification dataset saved in {self.save_folder}
                    X_data:
                        ---{x_save_path}
                    y_data:
                        ---{y_save_path}



                    """))
                    f.close()

            if task == 'multi':
                with open(os.path.join(self.save_folder, 'metadata.txt'), 'a') as f:
                    size_of_X, size_of_y, x_save_path, y_save_path = self._create_multi_dataset()

                    f.write(textwrap.dedent(f"""Creating multiclassification dataset
                    Path to save .npy files : {self.save_folder}


                    Size of X dataset: {size_of_X} features
                    Size of y dataset: {size_of_y} features

                    X_data saved in {x_save_path}
                    y_data saved in {y_save_path}


                    Multiclassification dataset saved in {self.save_folder}
                    X_data:
                        ---{x_save_path}
                    y_data:
                        ---{y_save_path}



                    """))
                    f.close()

            if task == 'full':
                with open(os.path.join(self.save_folder, 'metadata.txt'), 'a') as f:
                    size_of_X, size_of_y, x_save_path, y_save_path = self._create_full_dataset()
                    f.write(textwrap.dedent(f"""Creating multiclassification dataset with milk
                    Path to save .npy files : {self.save_folder}


                    Size of X dataset: {size_of_X} features
                    Size of y dataset: {size_of_y} features

                    X_data saved in {x_save_path}
                    y_data saved in {y_save_path}


                    Multiclassification dataset with milk saved in {self.save_folder}
                    X_data:
                        ---{x_save_path}
                    y_data:
                        ---{y_save_path}



                    """))
                    f.close()

            if task == 'regression':
                self._create_regression_dataset()

    def __create_list_of_antibiotics(self):
        listdir = os.listdir(self.folder)
        if 'prepared_data' in listdir:
            listdir.remove('prepared_data')
        return listdir

    def _list_of_csv_files(self):
        list_of_csv_files = []
        for root, dirs, files in os.walk(self.folder):
            for file in files:
                list_of_csv_files.append(os.path.join(root, file))
        return list_of_csv_files

    def _create_tasks(self):
        all_tasks = []
        if 'binary' in self.tasks:
            all_tasks.append('binary')
        if 'multi' in self.tasks:
            all_tasks.append('multi')
        if 'full' in self.tasks:
            all_tasks.append('full')
        if 'regression' in self.tasks:
            all_tasks.append('regression')

        return all_tasks

    def __read_current(self, path):
        lines = []
        current = []
        with open(path, 'r') as f:
            for line in f.readlines():
                line_list = line.split(' ')
                final_line = [x for x in line_list if x]
                lines.append(final_line[2])
            f.close()
        lines = lines[1:]
        for number in lines:
            current.append(float(number))
        if len(current) == 1044:
            current = current[:-4]
        return current

    def _create_binary_dataset(self):
        print(textwrap.dedent(f"""
        Creating binary dataset
        Path to save .npy files : {self.save_folder}
        """))

        X_data_binary = []
        y_data_binary = []
        X_data_save_folder = os.path.join(self.save_folder, 'X_data_binary_classification.npy')
        y_data_save_folder = os.path.join(self.save_folder, 'y_data_binary_classification.npy')

        for path in tqdm(self.list_of_csv_files):
            if 'milk' in path.split(os.sep):
                current = self.__read_current(path)
                if len(current) == 1040:
                    X_data_binary.append(np.array(current))
                    y_data_binary.append(str('milk'))
            else:
                current = self.__read_current(path)
                if len(current) == 1040:
                    X_data_binary.append(np.array(current))
                    y_data_binary.append(str('antibiotic'))

        X_data_binary = np.array(X_data_binary)
        y_data_binary = np.array(y_data_binary).astype(str)
        np.save(X_data_save_folder, X_data_binary)
        np.save(y_data_save_folder, y_data_binary)
        print(textwrap.dedent(f"""
        Binary classification dataset saved in {self.save_folder}
        X_data:
            ---{os.path.join(self.save_folder, 'X_data_binary_classification.npy')}
        y_data:
            ---{os.path.join(self.save_folder, 'y_data_binary_classification.npy')}
        """))

        return len(X_data_binary), len(y_data_binary), X_data_save_folder, y_data_save_folder

    def _create_multi_dataset(self):
        print(textwrap.dedent(f"""
        Creating multiclass dataset
        Path to save .npy files: {self.save_folder}
        """))

        X_data_multi = []
        y_data_multi = []
        X_data_save_folder = os.path.join(self.save_folder, 'X_data_multi_classification.npy')
        y_data_save_folder = os.path.join(self.save_folder, 'y_data_multi_classification.npy')

        for path in tqdm(self.list_of_csv_files):
            if 'milk' in path.split(os.sep):
                pass
            else:
                current = self.__read_current(path)
                if len(current) == 1040:
                    X_data_multi.append(np.array(current))
                    for antibiotic in self.list_of_antibiotics:
                        if antibiotic in path.split(os.sep):
                            y_data_multi.append(str(antibiotic))

        X_data_multi = np.array(X_data_multi)
        y_data_multi = np.array(y_data_multi).astype(str)
        np.save(X_data_save_folder, X_data_multi)
        np.save(y_data_save_folder, y_data_multi)
        print(textwrap.dedent(f"""
        Multiclassification dataset saved in {self.save_folder}
        X_data: 
            ---{os.path.join(self.save_folder, 'X_data_multi_classification.npy')}
        y_data:
            ---{os.path.join(self.save_folder, 'y_data_multi_classification.npy')}
        """))
        return len(X_data_multi), len(y_data_multi), X_data_save_folder, y_data_save_folder

    def _create_full_dataset(self):
        print(textwrap.dedent(f"""
        Creating multiclass dataset with milk
        Path to save .npy files: {self.save_folder}
        """))

        X_data = []
        y_data = []
        X_data_save_folder = os.path.join(self.save_folder, 'X_data_full_classification.npy')
        y_data_save_folder = os.path.join(self.save_folder, 'y_data_full_classification.npy')

        for path in tqdm(self.list_of_csv_files):
            current = self.__read_current(path)
            if len(current) == 1040:
                X_data.append(np.array(current))
                for antibiotic in self.list_of_antibiotics:
                    if antibiotic in path.split(os.sep):
                        y_data.append(str(antibiotic))

        X_data = np.array(X_data)
        y_data = np.array(y_data).astype(str)
        np.save(X_data_save_folder, X_data)
        np.save(y_data_save_folder, y_data)
        print(textwrap.dedent(f"""
        Multiclassification dataset saved in {self.save_folder}
        X_data:
            ---{os.path.join(self.save_folder, 'X_data_full_classification.npy')}
        y_data:
            ---{os.path.join(self.save_folder, 'y_data_full_classification.npy')}
        """))

        return len(X_data), len(y_data), X_data_save_folder, y_data_save_folder

    def _create_regression_dataset(self):
        print(textwrap.dedent(f"""
        Creating regression datasets
        Path to save .npy files: {self.save_folder}
        """))
        with open(os.path.join(self.save_folder, 'metadata.txt'), 'a') as f:
            f.write(textwrap.dedent(f"""
            Creating regression datasets
            Path to save .npy files: {self.save_folder}
            """))
            list_of_antibiotics = self.list_of_antibiotics.copy()
            list_of_antibiotics.remove('milk')
            for antibiotic in list_of_antibiotics:
                print(textwrap.dedent(f"""
                Creating dataset for regression
                Antibiotic: {antibiotic}
                """))
                f.write(textwrap.dedent(f"""
                Creating dataset for regression
                Antibiotic: {antibiotic}
                """))
                X_data = []
                y_data = []

                for path in tqdm(self.list_of_csv_files):
                    if antibiotic in path.split(os.sep):
                        current = self.__read_current(path)
                        if len(current) == 1040:
                            X_data.append(np.array(current))
                            number = float(path.split(os.sep)[-1].split('_')[0])
                            degree = float(path.split(os.sep)[-1].split('_')[2])
                            conc = float(number * 10 ** degree)
                            y_data.append(conc)

                X_data = np.array(X_data)
                y_data = np.array(y_data)
                np.save(os.path.join(self.save_folder, f'X_data_{antibiotic}_regression.npy'), X_data)
                np.save(os.path.join(self.save_folder, f'y_data_{antibiotic}_regression.npy'), y_data)
                print(textwrap.dedent(f"""
                Regression dataset for {antibiotic} saved in {self.save_folder}

                X_data:
                    ---{os.path.join(self.save_folder, f'X_data_{antibiotic}_regression.npy')}
                y_data:
                    ---{os.path.join(self.save_folder, f'y_data_{antibiotic}_regression.npy')}
                """))
                f.write(textwrap.dedent(f"""
                Regression dataset for {antibiotic} saved in {self.save_folder}

                Size of X data for {antibiotic}: {len(X_data)} features
                Size of y data for {antibiotic}: {len(y_data)} features

                X_data:
                    ---{os.path.join(self.save_folder, f'X_data_{antibiotic}_regression.npy')}
                y_data:
                    ---{os.path.join(self.save_folder, f'y_data_{antibiotic}_regression.npy')}
                """))
            f.close()

if __name__ == '__main__':
    Ivium(os.path.join(PATH_TO_DATA, 'ivium_new_data'), tasks=['regression'])

