import os
import random

import numpy as np
import pandas as pd

from model.ml_based.data_paths import NPY_SAVE_PATH, PREPARED_DATA_PATH
from model.ml_based.dataset import Dataset

random.seed(1)
np.random.seed(1)


def prepare_dataset_as_npy_arrays():
    """ Load and prepare data as npy files. Function for data preparation should run once. """
    path = 'data'
    save_path = 'prepared_data'

    if os.path.isdir(NPY_SAVE_PATH) is False:
        os.mkdir(NPY_SAVE_PATH)

    features, target = Dataset(path, save_path).create_data_and_labels_for_classification()
    x_train, x_val, x_test, y_train, y_val, y_test = Dataset.split_data(features, target)

    x_train = np.squeeze(np.asarray(x_train))
    y_train = np.asarray(y_train)

    x_test = np.squeeze(np.asarray(x_test))
    y_test = np.asarray(y_test)

    x_val = np.squeeze(np.asarray(x_val))
    y_val = np.asarray(y_val)

    np.save(os.path.join(NPY_SAVE_PATH, 'x_train.npy'), x_train)
    np.save(os.path.join(NPY_SAVE_PATH, 'y_train.npy'), y_train)

    np.save(os.path.join(NPY_SAVE_PATH, 'x_test.npy'), x_test)
    np.save(os.path.join(NPY_SAVE_PATH, 'y_test.npy'), y_test)

    np.save(os.path.join(NPY_SAVE_PATH, 'x_val.npy'), x_val)
    np.save(os.path.join(NPY_SAVE_PATH, 'y_val.npy'), y_val)


def prepare_classification_regression_table():
    """ Create table for all objects with all features for both classification and regression tasks """
    files = os.listdir(PREPARED_DATA_PATH)
    # Remain only npy files which starts with 'X_data' (features) and needed for regression task
    files = list(filter(lambda current_file: current_file.endswith('.npy'), files))
    files = list(filter(lambda current_file: 'regression' in current_file, files))
    features_files = list(filter(lambda current_file: current_file.startswith('X_data'), files))

    main_df = []
    for file in features_files:
        loaded_features_matrix = np.load(os.path.join(PREPARED_DATA_PATH, file))
        features_names = create_list_with_features(loaded_features_matrix)

        # Load target
        target_file = file.replace('X_data', 'y_data')
        loaded_target = np.load(os.path.join(PREPARED_DATA_PATH, target_file))

        # Generate common dataframe
        dataframe = pd.DataFrame(loaded_features_matrix, columns=features_names)
        dataframe['target'] = loaded_target

        current_substance = target_file.split('_')[-1]
        current_substance = current_substance[:-4]

        dataframe['substance'] = [current_substance] * len(dataframe)
        main_df.append(dataframe)

    ##########################
    # Prepare part with milk #
    ##########################
    milk_features_matrix = np.load(os.path.join(PREPARED_DATA_PATH, 'X_data_full_classification.npy'))
    milk_target = np.load(os.path.join(PREPARED_DATA_PATH, 'y_data_full_classification.npy'))
    features_names = create_list_with_features(milk_features_matrix)
    milk_df = pd.DataFrame(milk_features_matrix, columns=features_names)
    milk_df['target'] = [0] * len(milk_df)
    milk_df['substance'] = milk_target
    milk_df = milk_df[milk_df['substance'] == 'MILK']

    main_df.append(milk_df)
    main_df = pd.concat(main_df)
    return main_df


def create_list_with_features(matrix: np.array):
    """
    Generate list with features for matrix converting into pandas DataFrame in
    the future
    """
    n_rows, n_cols = matrix.shape
    features_names = [f'feature_{i}' for i in range(0, n_cols)]
    return features_names
