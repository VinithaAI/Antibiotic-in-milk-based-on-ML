import pandas as pd

import os
import random

import numpy as np
from sklearn.metrics import classification_report

from fedot.api.main import Fedot
from fedot.core.pipelines.node import PrimaryNode, SecondaryNode
from fedot.core.pipelines.pipeline import Pipeline

from model.fedot_based.data_preparation import NPY_SAVE_PATH

random.seed(1)
np.random.seed(1)


def get_initial_pipeline():
    """ Return initial pipeline """
    scaling_node = PrimaryNode('scaling')
    pca_node = SecondaryNode('pca', nodes_from=[scaling_node])
    pca_node.custom_params = {'n_components': 0.2}
    initial_pipeline = Pipeline(SecondaryNode('dt', nodes_from=[pca_node]))

    return initial_pipeline


def save_predictions(x_test, y_test, predict):
    # Save predictions in csv file
    result_dict = {}
    n_rows, n_cols = x_test.shape
    for i in range(n_cols):
        result_dict.update({f'feature_{i}': x_test[:, i]})
    result_dict.update({'predict': predict})
    result_dict.update({'actual': y_test})

    df = pd.DataFrame(result_dict)
    df.to_csv('predictions.csv', index=False)


def run_fedot(timeout: float = 0.5, features_for_train: int = None):
    """ Launch fedot on dataset

    :param timeout: time for AutoML in minutes
    :param features_for_train: how many columns (features) to use from dataset
    """
    x_train = np.load(os.path.join(NPY_SAVE_PATH, 'x_train.npy'))
    y_train = np.load(os.path.join(NPY_SAVE_PATH, 'y_train.npy'))

    x_test = np.load(os.path.join(NPY_SAVE_PATH, 'x_test.npy'))
    y_test = np.load(os.path.join(NPY_SAVE_PATH, 'y_test.npy'))

    x_val = np.load(os.path.join(NPY_SAVE_PATH, 'x_val.npy'))
    y_val = np.load(os.path.join(NPY_SAVE_PATH, 'y_val.npy'))

    if features_for_train is not None:
        # Clip arrays
        x_train = x_train[:, :features_for_train]
        x_test = x_test[:, :features_for_train]
        x_val = x_val[:, :features_for_train]

    available_operations = ['bernb', 'dt', 'knn', 'lda', 'qda', 'logit', 'rf', 'svc',
                            'scaling', 'normalization', 'pca', 'kernel_pca']

    initial_pipeline = get_initial_pipeline()
    automl = Fedot(problem='classification', timeout=timeout,
                   verbose_level=4, composer_params={'timeout': timeout,
                                                     'available_operations': available_operations,
                                                     'initial_pipeline': initial_pipeline})
    pipeline = automl.fit(x_train, target=y_train)
    predict = automl.predict(x_test)

    # Display obtained composite model structure
    pipeline.show()

    # Serialize pipeline with name timeout and features_for_train info
    if features_for_train is None:
        features_for_train = 'all'
    pipeline.save(f'pipeline_{timeout}_{features_for_train}')

    # Features and predictions into csv file
    save_predictions(x_test, y_test, predict)

    # Calculate metrics
    print(classification_report(y_test, predict))


if __name__ == '__main__':
    run_fedot(timeout=10, features_for_train=None)
