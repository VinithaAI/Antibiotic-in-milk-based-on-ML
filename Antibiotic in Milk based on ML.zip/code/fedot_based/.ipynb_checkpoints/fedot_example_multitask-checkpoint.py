import os
import random

import numpy as np
import pandas as pd
from fedot.api.main import Fedot
from fedot.core.data.data import InputData
from fedot.core.data.multi_modal import MultiModalData
from fedot.core.pipelines.node import PrimaryNode, SecondaryNode
from fedot.core.pipelines.pipeline import Pipeline
from fedot.core.repository.dataset_types import DataTypesEnum
from fedot.core.repository.tasks import Task, TaskTypesEnum
from sklearn.metrics import mean_absolute_error, mean_squared_error, max_error, median_absolute_error, r2_score, \
    explained_variance_score

from model.fedot_based.data_preparation import NPY_SAVE_PATH

random.seed(1)
np.random.seed(1)


def regression_report(y_true, y_pred):
    error = y_true - y_pred
    percentil = [5, 25, 50, 75, 95]
    percentil_value = np.percentile(error, percentil)

    metrics = [
        ('mean absolute error', mean_absolute_error(y_true, y_pred)),
        ('median absolute error', median_absolute_error(y_true, y_pred)),
        ('mean squared error', mean_squared_error(y_true, y_pred)),
        ('max error', max_error(y_true, y_pred)),
        ('r2 score', r2_score(y_true, y_pred)),
        ('explained variance score', explained_variance_score(y_true, y_pred))
    ]

    print('Metrics for regression:')
    for metric_name, metric_value in metrics:
        print(f'{metric_name:>25s}: {metric_value: >20.3f}')

    print('\nPercentiles:')
    for p, pv in zip(percentil, percentil_value):
        print(f'{p: 25d}: {pv:>20.3f}')


def get_initial_pipeline():
    """ Return initial pipeline """

    ds_regr = PrimaryNode('data_source_table/regr')
    ds_class = PrimaryNode('data_source_table/class')

    scaling_node_regr = SecondaryNode('scaling', nodes_from=[ds_regr])
    scaling_node_class = SecondaryNode('scaling', nodes_from=[ds_class])

    pca_node_regr = SecondaryNode('pca', nodes_from=[scaling_node_regr])
    pca_node_regr.custom_params = {'n_components': 0.2}

    pca_node_class = SecondaryNode('pca', nodes_from=[scaling_node_class])
    pca_node_class.custom_params = {'n_components': 0.2}

    class_node = SecondaryNode('dt', nodes_from=[scaling_node_class])

    root_regr = SecondaryNode('dtreg', nodes_from=[scaling_node_regr, class_node])

    initial_pipeline = Pipeline(root_regr)

    initial_pipeline.show()

    return initial_pipeline


def save_predictions(x_test, y_test, predict):
    # Save predictions in csv file
    result_dict = {}
    n_rows, n_cols = x_test.shape
    for i in range(n_cols):
        result_dict.update({f'feature_{i}': x_test[:, i]})
    result_dict.update({'predict': predict})
    result_dict.update({'actual': y_test})

    df = pd.DataFrame(result_dict)
    df.to_csv('predictions.csv', index=False)


def run_fedot(timeout: float = 0.5, features_for_train: int = None):
    """ Launch fedot on dataset

    :param timeout: time for AutoML in minutes
    :param features_for_train: how many columns (features) to use from dataset
    """
    x_train = np.load(os.path.join(NPY_SAVE_PATH, 'x_train.npy'))
    y_train = np.load(os.path.join(NPY_SAVE_PATH, 'y_train.npy'))

    x_test = np.load(os.path.join(NPY_SAVE_PATH, 'x_test.npy'))
    y_test = np.load(os.path.join(NPY_SAVE_PATH, 'y_test.npy'))

    x_val = np.load(os.path.join(NPY_SAVE_PATH, 'x_val.npy'))
    y_val = np.load(os.path.join(NPY_SAVE_PATH, 'y_val.npy'))

    if features_for_train is not None:
        # Clip arrays
        x_train = x_train[:, :features_for_train]
        x_test = x_test[:, :features_for_train]
        x_val = x_val[:, :features_for_train]

    available_operations = ['bernb', 'dt', 'knn', 'lda', 'qda', 'logit', 'rf',
                            'scaling', 'normalization', 'pca', 'kernel_pca']

    initial_pipeline = get_initial_pipeline()
    automl = Fedot(problem='regression', timeout=timeout,
                   verbose_level=4, composer_params={'timeout': timeout,
                                                     'available_operations': available_operations,
                                                     'initial_assumption': initial_pipeline},
                   safe_mode=False)

    idx = np.arange(len(y_train))

    # dummy value for regression target
    y_regr_train = np.asarray(random.sample(range(0, 1000), len(y_train)))
    y_regr_test = np.asarray(random.sample(range(0, 1000), len(y_test)))

    train_regr = InputData(idx=idx, features=x_train, target=y_regr_train , data_type=DataTypesEnum.table,
                           task=Task(TaskTypesEnum.regression))

    train_class = InputData(idx=idx, features=x_train, target=y_train, data_type=DataTypesEnum.table,
                            task=Task(TaskTypesEnum.classification))
    train_class.supplementary_data.is_main_target = False

    predict_regr = InputData(idx=idx, features=x_test, target=None, data_type=DataTypesEnum.table,
                             task=Task(TaskTypesEnum.regression))

    predict_class = InputData(idx=idx, features=x_test, target=None, data_type=DataTypesEnum.table,
                              task=Task(TaskTypesEnum.classification))
    predict_class.supplementary_data.is_main_target = False

    fit_data = MultiModalData({
        'data_source_table/regr': train_regr,
        'data_source_table/class': train_class
    })

    predict_data = MultiModalData({
        'data_source_table/regr': predict_regr,
        'data_source_table/class': predict_class
    })

    pipeline = automl.fit(fit_data)
    predict = automl.predict(predict_data)

    # Display obtained composite model structure
    pipeline.show()

    # Serialize pipeline with name timeout and features_for_train info
    if features_for_train is None:
        features_for_train = 'all'
    pipeline.save(f'pipeline_{timeout}_{features_for_train}')

    # extract predictions for classification part
    class_sub_pipeline = Pipeline(pipeline.root_node.nodes_from[1])
    class_sub_pipeline.fit_from_scratch(fit_data)
    predict_class = class_sub_pipeline.predict(predict_data, output_mode='labels').predict

    # Features and predictions into csv file
    save_predictions(x_test, y_regr_test, predict)

    # Calculate metrics
    print(regression_report(y_regr_test, predict))


if __name__ == '__main__':
    run_fedot(timeout=0.1, features_for_train=10)
