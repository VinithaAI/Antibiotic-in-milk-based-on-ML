import os
import numpy as np
import pandas as pd
import datetime

from fedot.core.data.data import InputData
from fedot.core.data.multi_modal import MultiModalData
from fedot.core.data.supplementary_data import SupplementaryData
from fedot.core.pipelines.node import PrimaryNode, SecondaryNode
from fedot.core.pipelines.pipeline import Pipeline
from fedot.core.repository.dataset_types import DataTypesEnum
from fedot.core.repository.tasks import TaskTypesEnum, Task
from sklearn.metrics import classification_report, mean_absolute_error

from model.fedot_based.data_preparation import prepare_classification_regression_table
from model.ml_based.data_paths import SERIALIZED_MODELS_PATH


def get_multitask_pipeline():
    data_source_classification = PrimaryNode('data_source_table/classification')
    data_source_regression = PrimaryNode('data_source_table/regression')

    classification_node = SecondaryNode('rf', nodes_from=[data_source_classification])
    final_node = SecondaryNode('rfr', nodes_from=[classification_node, data_source_regression])
    return Pipeline(final_node)


def prepare_multimodal_data_from_df(dataframe: pd.DataFrame):
    """ Wrap dataframe into InputData dataclass for FEDOT """
    features_names = list(dataframe.columns[:-2])
    # Data for classification
    class_task = Task(TaskTypesEnum.classification)
    class_input = InputData(idx=np.arange(0, len(dataframe)),
                            features=np.array(dataframe[features_names]),
                            target=np.array(dataframe['substance']),
                            task=class_task, data_type=DataTypesEnum.table,
                            supplementary_data=SupplementaryData(is_main_target=False))

    # Data for regression
    task = Task(TaskTypesEnum.regression)
    regression_input = InputData(idx=np.arange(0, len(dataframe)),
                                 features=np.array(dataframe[features_names]),
                                 target=np.array(dataframe['target']),
                                 task=task, data_type=DataTypesEnum.table)

    # Important! Name of primary nodes in the pipelines should be determined as keys here
    multimodal_data = MultiModalData({'data_source_table/classification': class_input,
                                      'data_source_table/regression': regression_input})
    return multimodal_data


def fit_multitask_simple_pipeline():
    """ Example of making predictions for classification and regression task """
    dataframe = prepare_classification_regression_table()
    # Transform data into appropriate dataclass
    multimodal_data = prepare_multimodal_data_from_df(dataframe)

    multitask_pipeline = get_multitask_pipeline()

    # Tune pipeline
    starting_time = datetime.datetime.now()
    multitask_pipeline = multitask_pipeline.fine_tune_all_nodes(loss_function=mean_absolute_error,
                                                                input_data=multimodal_data,
                                                                timeout=10,
                                                                iterations=10)
    fit_time = datetime.datetime.now() - starting_time
    print(f'Time to tune the pipeline: {fit_time}')
    multitask_pipeline.show()
    # Train model and save it
    starting_time = datetime.datetime.now()
    multitask_pipeline.fit(multimodal_data)
    fit_time = datetime.datetime.now() - starting_time
    print(f'Time to fit the pipeline: {fit_time}')

    multitask_pipeline.save(os.path.join(SERIALIZED_MODELS_PATH, 'simple'))


def predict_multitask_simple_pipeline():
    """ Using an already fitted pipeline it is possible to generate forecasts """
    loaded_pipeline = Pipeline()
    load_path = os.path.join(SERIALIZED_MODELS_PATH, 'multitask_pipeline', 'simple.json')
    loaded_pipeline.load(load_path)

    # Prepare train sample
    dataframe = prepare_classification_regression_table()
    multimodal_data = prepare_multimodal_data_from_df(dataframe)

    # Replace the name of main "data source" in preprocessor
    side_pipeline = loaded_pipeline.pipeline_for_side_task(task_type=TaskTypesEnum.classification)
    side_pipeline.preprocessor.main_target_source_name = 'data_source_table/classification'
    side_pipeline.show()
    side_output = side_pipeline.predict(multimodal_data, output_mode='labels')
    output = loaded_pipeline.predict(multimodal_data)

    predicted_classes = np.ravel(side_output.predict)
    predicted_concentrations = np.ravel(output.predict)
    print(f'Predicted classes: {predicted_classes[:5]}')
    print(f'Predicted concentrations: {predicted_concentrations[:5]}\n')

    actual_classes = np.ravel(np.array(dataframe['substance']))
    actual_concentrations = np.ravel(np.array(dataframe['target']))
    print(f"Actual classes: {actual_classes[:5]}")
    print(f"Actual concentrations: {actual_concentrations[:5]}")

    print(classification_report(actual_classes, predicted_classes))


if __name__ == '__main__':
    # fit_multitask_simple_pipeline()
    predict_multitask_simple_pipeline()
