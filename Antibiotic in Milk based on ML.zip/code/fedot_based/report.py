import os
import numpy as np

from fedot.core.data.data import InputData
from fedot.core.pipelines.pipeline import Pipeline
from fedot.core.repository.dataset_types import DataTypesEnum
from fedot.core.repository.tasks import Task, TaskTypesEnum
from sklearn.metrics import classification_report
from sklearn.metrics import roc_auc_score

from model.fedot_based.fedot_example import NPY_SAVE_PATH


def prepare_input_data(path_to_model, features):
    """
    For FEDOT to run on new data not through API, you need to put the array
    in a special data class (InputData)
    """
    pipeline_name = os.path.basename(path_to_model)
    splitted = pipeline_name.split('_')[-1]
    number_of_features = splitted.split('.')[0]

    if number_of_features != 'all':
        # Model was prepared on subsample of the dataset
        number_of_features = int(number_of_features)
        # Take first features (columns)
        features = features[:, :number_of_features]

    task = Task(TaskTypesEnum.classification)
    features_input = InputData(idx=np.arange(len(features)),
                               features=features, target=None,
                               task=task, data_type=DataTypesEnum.table)

    return features_input


def load_pipeline_and_make_forecast(features: np.array, target_actual: np.array,
                                    path_to_model: str):
    """ An example showing how to load pipeline and make predictions

    :param features: array with features
    :param target_actual: actual values of target column
    :param path_to_model: path to serialized pipeline
    """
    pipeline = Pipeline()
    pipeline.load(path_to_model)

    features_input = prepare_input_data(path_to_model, features)

    # If you want to get probabilities
    probs_output = pipeline.predict(features_input).predict

    # If you want to obtain labels
    labels_output = pipeline.predict(features_input, output_mode='labels').predict

    # Display metrics
    print(classification_report(target_actual, labels_output))
    roc_auc = roc_auc_score(target_actual, probs_output, multi_class="ovr")
    print(f'ROC AUC score: {roc_auc:.3f}')


if __name__ == '__main__':
    x_val = np.load(os.path.join(NPY_SAVE_PATH, 'x_val.npy'))
    y_val = np.load(os.path.join(NPY_SAVE_PATH, 'y_val.npy'))

    serialized_pipeline = 'December-25-2021,20-41-27,PM pipeline_10_all/pipeline_10_all.json'
    model_path = os.path.join(os.path.abspath(os.path.curdir), serialized_pipeline)

    load_pipeline_and_make_forecast(features=x_val, target_actual=y_val,
                                    path_to_model=model_path)
