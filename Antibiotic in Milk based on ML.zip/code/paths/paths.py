import os
from pathlib import Path


def get_project_path() -> str:
    """
    Function for creating project path
    :return: Project path
    """

    return Path(__file__).parent.parent.parent

PATH_TO_PROJECT = get_project_path()
PATH_TO_EVALUATION = os.path.join(get_project_path(), 'evaluations')
PATH_TO_DATA = os.path.join(get_project_path(), 'data')
SERIALIZED_MODELS_PATH = os.path.join(get_project_path(), 'serialized')
PREPARED_DATA_PATH = os.path.join(get_project_path(), 'data', 'ivium_new_data', 'prepared_data')
PREPARED_DATA_PATH_GALACTICUM = os.path.join(get_project_path(), 'data', 'galacticum_new_data', 'prepared_data')