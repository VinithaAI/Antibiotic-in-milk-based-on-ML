import os
from code.paths.paths import PATH_TO_PROJECT

class Input_File:
    def __init__(self, path_to_file):
        self.path_to_file = path_to_file
        self.write_input_file()

    def write_input_file(self):
        self.dataset = None
        self.folder_name = None
        self.tasks = []
        self.normalize = None
        self.frameworks = []
        self.grid_files = []
        self.read_input_file_line()

    def read_input_file_line(self):
        with open(self.path_to_file, 'r') as f:
            for line in f.readlines():
                if line.startswith('#'):
                    pass
                if line.startswith('1'):
                    self.dataset = line.split('=')[-1]
                if line.startswith('2'):
                    self.folder_name = line.split('=')[-1]
                if line.startswith('3'):
                    for task in line.replace('3', '').replace('.', '').strip().split(','):
                        self.tasks.append(task.strip())
                if line.startswith('4'):
                    if line.split('=')[-1] == 'False':
                        self.normalize = False
                    else:
                        self.normalize = True
                if line.startswith('5'):
                    frameworks = line.replace('5', '').replace('.', '').strip().split(',')
                    self.frameworks = ','.join(frameworks).split('=')[-1].split(',')
                if line.startswith('6'):
                    files_grid = line.replace('6', '').strip().split(',')
                    for grid in files_grid:
                        file = grid.split('=')[-1]
                        path_to_file = os.path.join(PATH_TO_PROJECT, file)
                        self.grid_files.append(path_to_file)
            f.close()




if __name__ == '__main__':
    path_to_file = os.path.join(PATH_TO_PROJECT, 'input.txt')
    Input_File(path_to_file)