from code.paths.paths import PATH_TO_PROJECT
from code.models.start import main
import sys, os

def create_create_inputs():
    inputs = []
    input_file = sys.argv[1]
    with open(os.path.join(PATH_TO_PROJECT, input_file), 'r') as f:
        for line in f.readlines():
            inputs.append(line.strip())
    return inputs


if __name__ == '__main__':
    variables = create_create_inputs()
    main(variables)

