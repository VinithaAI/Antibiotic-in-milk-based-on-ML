from code.models.catboost import *
from code.models.xgboost import *
from code.paths.paths import PATH_TO_DATA, PATH_TO_EVALUATION
from code.dataset.parce_galacticum import Galacticum
from code.dataset.parce_ivium import Ivium
from code.evaluation.plot import Plot_ML_data
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.metrics import classification_report
from sklearn import metrics
from datetime import datetime
from xgboost import XGBRegressor, XGBClassifier
import pandas as pd
import numpy as np
import shutil
import json
import os

class Setup_models:
    def __init__(self, variables):
        tasks = variables[2:-1]
        if variables[-1] == 'Normalize=True':
            normalize = True
        else:
            normalize = False
        if variables[0] == 'galacticum':
            dataset = Galacticum(os.path.join(PATH_TO_DATA, variables[1]), normalize=normalize, tasks=tasks)
        if variables[0] == 'ivium':
            dataset = Ivium(os.path.join(PATH_TO_DATA, variables[1]), normalize=normalize, tasks=tasks)

        self.dataset = dataset
        self.date = datetime.now().strftime("%Y_%m_%d-%I:%M:%S_%p")
        self.evaluations_path = os.path.join(PATH_TO_EVALUATION, variables[1])

        if os.path.exists(self.evaluations_path):
            pass
        else:
            os.mkdir(self.evaluations_path)

        if os.path.exists(os.path.join(self.evaluations_path, 'catboost')):
            pass
        else:
            os.mkdir(os.path.join(self.evaluations_path, 'catboost'))

        if os.path.exists(os.path.join(self.evaluations_path, 'xgboost')):
            pass
        else:
            os.mkdir(os.path.join(self.evaluations_path, 'xgboost'))


        self.catboost_evaluation_path = os.path.join(self.evaluations_path, 'catboost')
        self.xgboost_evaluation_path = os.path.join(self.evaluations_path, 'xgboost')


    def run_catboost(self):
        for task in self.dataset.tasks:
            print(task)
            if task == 'regression':

                if os.path.exists(os.path.join(self.catboost_evaluation_path, task)):
                    pass
                else:
                    os.mkdir(os.path.join(self.catboost_evaluation_path, task))

                list_of_antibiotics = self.dataset.list_of_antibiotics.copy()
                if 'milk' in list_of_antibiotics:
                    list_of_antibiotics.remove('milk')
                for antibiotic in list_of_antibiotics:
                    if os.path.exists(os.path.join(self.catboost_evaluation_path, task, antibiotic)):
                        pass
                    else:
                        os.mkdir(os.path.join(self.catboost_evaluation_path, task, antibiotic))

                    X_data_path = os.path.join(self.dataset.save_folder, f'X_data_{antibiotic}_regression.npy')
                    y_data_path = os.path.join(self.dataset.save_folder, f'y_data_{antibiotic}_regression.npy')

                    X_data = np.load(X_data_path, allow_pickle=True)
                    y_data = np.load(y_data_path, allow_pickle=True)

                    X_train, X_test, y_train, y_test = train_test_split(X_data, y_data, random_state=42, test_size=0.2)
                    model = create_catboost_regressor()
                    grid = grid_search_params()
                    grid_search_results = model.grid_search(grid, X=X_train, y=y_train, cv=10,
                                                            refit=True,
                                                            train_size=0.2)
                    pred = model.predict(X_test)
                    model.save_model(os.path.join(self.catboost_evaluation_path, task, antibiotic, 'model'))
                    mae = metrics.mean_absolute_error(y_test, pred)
                    mse = metrics.mean_squared_error(y_test, pred)
                    r2 = metrics.r2_score(y_test, pred)

                    y_test = np.array(y_test)

                    print("The model performance for testing set")
                    print("--------------------------------------")
                    print('MAE is {}'.format(mae))
                    print('MSE is {}'.format(mse))
                    print('R2 score is {}'.format(r2))
                    np.save(os.path.join(self.catboost_evaluation_path, task, antibiotic, 'X_test.npy'), X_test)
                    np.save(os.path.join(self.catboost_evaluation_path, task, antibiotic, 'y_test.npy'), y_test)
                    np.save(os.path.join(self.catboost_evaluation_path, task, antibiotic, 'y_pred.npy'), pred)
                    with open(os.path.join(self.catboost_evaluation_path, task, antibiotic, 'Accuracy.txt'),
                              'w') as file:
                        file.write(f'MAE is {mae}\n')
                        file.write(f'MSE is {mse}\n')
                        file.write(f'R2 score is {r2}\n')
                        file.close()

                    with open(os.path.join(self.catboost_evaluation_path, task, antibiotic, 'best_params.json'),
                              'w') as fp:
                        json.dump(grid_search_results, fp, indent=4)

            else:
                if os.path.exists(os.path.join(self.catboost_evaluation_path, task)):
                    pass
                else:
                    os.mkdir(os.path.join(self.catboost_evaluation_path, task))

                list_datasets = os.listdir(os.path.join(self.dataset.save_folder))
                list_datasets.remove('metadata.txt')
                X_data_path = os.path.join(self.dataset.save_folder, f'X_data_{task}_classification.npy')
                y_data_path = os.path.join(self.dataset.save_folder, f'y_data_{task}_classification.npy')

                X_data = np.load(X_data_path, allow_pickle=True)
                y_data = np.load(y_data_path, allow_pickle=True)
                X_train, X_test, y_train, y_test = train_test_split(X_data, y_data, random_state=42, test_size=0.2)
                grid = grid_search_params()
                model = create_catboost_classifier()
                grid_search_results = model.grid_search(grid, X=X_train, y=y_train, stratified=True, cv=10, refit=True,
                                                train_size=0.1)
                y_pred = model.predict(X_test)
                y_prob = model.predict_proba(X_test)
                model.save_model(os.path.join(self.catboost_evaluation_path, task, 'model'))
                report = classification_report(y_test, y_pred, output_dict=True)
                report_df = pd.DataFrame.from_dict(report)
                report_df.to_csv(os.path.join(self.catboost_evaluation_path, task, 'classification_report.csv'))
                np.save(os.path.join(self.catboost_evaluation_path, task, 'y_prob.npy'), y_prob)
                np.save(os.path.join(self.catboost_evaluation_path, task, 'X_test.npy'), X_test)
                np.save(os.path.join(self.catboost_evaluation_path, task, 'y_test.npy'), y_test)
                np.save(os.path.join(self.catboost_evaluation_path, task, 'y_pred.npy'), y_pred)
                with open(os.path.join(self.catboost_evaluation_path, task, 'best_params.json'), 'w') as fp:
                    json.dump(grid_search_results, fp, indent=4)
                    fp.close()
        self.date = datetime.now().strftime("%Y_%m_%d-%I:%M:%S_%p")
        self.list_catboost_evaluation_path = self.catboost_evaluation_path.split(os.sep)
        self.list_catboost_evaluation_path[-1] = 'catboost' + self.date
        self.date_catboost_evaluation_path = os.sep.join(self.list_catboost_evaluation_path)
        os.rename(self.catboost_evaluation_path, self.date_catboost_evaluation_path)
        Plot_ML_data(self.date_catboost_evaluation_path, self.dataset.tasks, self.dataset.list_of_antibiotics)
        shutil.copyfile(os.path.join(self.dataset.save_folder, 'metadata.txt'),
                        os.path.join(self.date_catboost_evaluation_path, 'metadata.txt'))



    def run_xgboost(self):
        for task in self.dataset.tasks:
            if task == 'regression':

                if os.path.exists(os.path.join(self.xgboost_evaluation_path, task)):
                    pass
                else:
                    os.mkdir(os.path.join(self.xgboost_evaluation_path, task))

                list_of_antibiotics = self.dataset.list_of_antibiotics.copy()
                if 'milk' in list_of_antibiotics:
                    list_of_antibiotics.remove('milk')
                for antibiotic in list_of_antibiotics:
                    if os.path.exists(os.path.join(self.xgboost_evaluation_path, task, antibiotic)):
                        pass
                    else:
                        os.mkdir(os.path.join(self.xgboost_evaluation_path, task, antibiotic))

                    X_data_path = os.path.join(self.dataset.save_folder, f'X_data_{antibiotic}_regression.npy')
                    y_data_path = os.path.join(self.dataset.save_folder, f'y_data_{antibiotic}_regression.npy')

                    X_data = np.load(X_data_path, allow_pickle=True)
                    y_data = np.load(y_data_path, allow_pickle=True)

                    X_train, X_test, y_train, y_test = train_test_split(X_data, y_data, random_state=42, test_size=0.2)
                    X_train, X_val, y_train, y_val = train_test_split(X_train, y_train, random_state=42, test_size=0.2)
                    model = create_xgboost_regressor()
                    grid = create_grip_params_xgboost()
                    grid_search_results = GridSearchCV(model, grid, cv=5, scoring='accuracy', verbose=0)
                    _ = grid_search_results.fit(X_train, y_train, eval_set=[(X_train, y_train), (X_val, y_val)],
                                                early_stopping_rounds=500)
                    final_model = XGBRegressor(
                        **grid_search_results.best_params_,
                        objective='reg:squarederror',
                        # colsample_bytree=0.5,
                        # subsample=0.8,
                        tree_method='gpu_hist',
                        verbosity=0
                    )
                    _ = final_model.fit(X_train, y_train, eval_set=[(X_train, y_train), (X_val, y_val)],
                                        early_stopping_rounds=500, verbose=False)
                    pred = final_model.predict(X_test)
                    final_model.save_model(os.path.join(self.xgboost_evaluation_path, task, antibiotic,
                                                               'model.json'))
                    mae = metrics.mean_absolute_error(y_test, pred)
                    mse = metrics.mean_squared_error(y_test, pred)
                    r2 = metrics.r2_score(y_test, pred)

                    y_test = np.array(y_test)

                    print("The model performance for testing set")
                    print("--------------------------------------")
                    print('MAE is {}'.format(mae))
                    print('MSE is {}'.format(mse))
                    print('R2 score is {}'.format(r2))
                    np.save(os.path.join(self.xgboost_evaluation_path, task, antibiotic, 'X_test.npy'), X_test)
                    np.save(os.path.join(self.xgboost_evaluation_path, task, antibiotic, 'y_test.npy'), y_test)
                    np.save(os.path.join(self.xgboost_evaluation_path, task, antibiotic, 'y_pred.npy'), pred)
                    with open(os.path.join(self.xgboost_evaluation_path, task, antibiotic, 'Accuracy.txt'),
                              'w') as file:
                        file.write(f'MAE is {mae}\n')
                        file.write(f'MSE is {mse}\n')
                        file.write(f'R2 score is {r2}\n')
                        file.close()

                    with open(os.path.join(self.xgboost_evaluation_path, task, antibiotic, 'best_params.json'),
                              'w') as fp:
                        json.dump(grid_search_results.best_params_, fp, indent=4)
                        fp.close()
            elif task == 'binary':
                if os.path.exists(os.path.join(self.xgboost_evaluation_path, task)):
                    pass
                else:
                    os.mkdir(os.path.join(self.xgboost_evaluation_path, task))

                    list_datasets = os.listdir(os.path.join(self.dataset.save_folder))
                    list_datasets.remove('metadata.txt')
                    X_data_path = os.path.join(self.dataset.save_folder, f'X_data_{task}_classification.npy')
                    y_data_path = os.path.join(self.dataset.save_folder, f'y_data_{task}_classification.npy')

                    X_data = np.load(X_data_path, allow_pickle=True)
                    y_data = np.load(y_data_path, allow_pickle=True)
                    X_train, X_test, y_train, y_test = train_test_split(X_data, y_data, random_state=42, test_size=0.2)
                    X_train, X_val, y_train, y_val = train_test_split(X_train, y_train, random_state=42, test_size=0.2)
                    grid = create_grip_params_xgboost()
                    model = create_xgboost_classifier_binary()
                    grid_search_results = GridSearchCV(model, grid, cv=5, scoring='accuracy', verbose=0)
                    _ = grid_search_results.fit(X_train, y_train, eval_set=[(X_train, y_train), (X_val, y_val)], early_stopping_rounds=500)
                    final_model = XGBClassifier(
                        **grid_search_results.best_params_,
                        objective='binary:logistic',
                        # colsample_bytree=0.5,
                        # subsample=0.8,
                        tree_method='gpu_hist',
                        verbosity=0
                    )
                    _ = final_model.fit(X_train, y_train, eval_set=[(X_train, y_train), (X_val, y_val)],
                                        early_stopping_rounds=500, verbose=False)
                    y_pred = final_model.predict(X_test)
                    y_prob = final_model.predict_proba(X_test)
                    final_model.save_model(os.path.join(self.xgboost_evaluation_path, task, 'model.json'))
                    report = classification_report(y_test, y_pred, output_dict=True)
                    report_df = pd.DataFrame.from_dict(report)
                    report_df.to_csv(os.path.join(self.xgboost_evaluation_path, task, 'classification_report.csv'))
                    np.save(os.path.join(self.xgboost_evaluation_path, task, 'y_prob.npy'), y_prob)
                    np.save(os.path.join(self.xgboost_evaluation_path, task, 'X_test.npy'), X_test)
                    np.save(os.path.join(self.xgboost_evaluation_path, task, 'y_test.npy'), y_test)
                    np.save(os.path.join(self.xgboost_evaluation_path, task, 'y_pred.npy'), y_pred)
                    with open(os.path.join(self.xgboost_evaluation_path, task, 'best_params.json'), 'w') as fp:
                        json.dump(grid_search_results.best_params_, fp, indent=4)
                        fp.close()
            else:
                if os.path.exists(os.path.join(self.xgboost_evaluation_path, task)):
                    pass
                else:
                    os.mkdir(os.path.join(self.xgboost_evaluation_path, task))

                    list_datasets = os.listdir(os.path.join(self.dataset.save_folder))
                    list_datasets.remove('metadata.txt')
                    X_data_path = os.path.join(self.dataset.save_folder, f'X_data_{task}_classification.npy')
                    y_data_path = os.path.join(self.dataset.save_folder, f'y_data_{task}_classification.npy')

                    X_data = np.load(X_data_path, allow_pickle=True)
                    y_data = np.load(y_data_path, allow_pickle=True)
                    X_train, X_test, y_train, y_test = train_test_split(X_data, y_data, random_state=42, test_size=0.2)
                    X_train, X_val, y_train, y_val = train_test_split(X_train, y_train, random_state=42, test_size=0.2)
                    grid = create_grip_params_xgboost()
                    model = create_xgboost_classifier_multi()
                    grid_search_results = GridSearchCV(model, grid, cv=5, scoring='accuracy', verbose=0)
                    _ = grid_search_results.fit(X_train, y_train, eval_set=[(X_train, y_train), (X_val, y_val)],  early_stopping_rounds=500)
                    final_model = XGBClassifier(
                        **grid_search_results.best_params_,
                        objective='multi:softprob',
                        # colsample_bytree=0.5,
                        # subsample=0.8,
                        tree_method='gpu_hist',
                        verbosity=0
                    )
                    _ = final_model.fit(X_train, y_train, eval_set=[(X_train, y_train), (X_val, y_val)],
                                        early_stopping_rounds=500, verbose=False)
                    y_pred = final_model.predict(X_test)
                    y_prob = final_model.predict_proba(X_test)
                    final_model.save_model(os.path.join(self.xgboost_evaluation_path, task, 'model.json'))
                    report = classification_report(y_test, y_pred, output_dict=True)
                    report_df = pd.DataFrame.from_dict(report)
                    report_df.to_csv(os.path.join(self.xgboost_evaluation_path, task, 'classification_report.csv'))
                    np.save(os.path.join(self.xgboost_evaluation_path, task, 'y_prob.npy'), y_prob)
                    np.save(os.path.join(self.xgboost_evaluation_path, task, 'X_test.npy'), X_test)
                    np.save(os.path.join(self.xgboost_evaluation_path, task, 'y_test.npy'), y_test)
                    np.save(os.path.join(self.xgboost_evaluation_path, task, 'y_pred.npy'), y_pred)
                    with open(os.path.join(self.xgboost_evaluation_path, task, 'best_params.json'), 'w') as fp:
                        json.dump(grid_search_results.best_params_, fp, indent=4)
                        fp.close()


        self.date = datetime.now().strftime("%Y_%m_%d-%I:%M:%S_%p")
        self.list_xgboost_evaluation_path = self.xgboost_evaluation_path.split(os.sep)
        self.list_xgboost_evaluation_path[-1] = 'xgboost' + self.date
        self.date_xgboost_evaluation_path = os.sep.join(self.list_xgboost_evaluation_path)
        os.rename(self.xgboost_evaluation_path, self.date_xgboost_evaluation_path)
        Plot_ML_data(self.date_xgboost_evaluation_path, self.dataset.tasks, self.dataset.list_of_antibiotics)
        shutil.copyfile(os.path.join(self.dataset.save_folder, 'metadata.txt'),
                        os.path.join(self.date_xgboost_evaluation_path, 'metadata.txt'))



def main(variables):
    models = Setup_models(variables)
    models.run_catboost()
    models.run_xgboost()

