from catboost import CatBoostClassifier, CatBoostRegressor

def create_catboost_classifier():
    model = CatBoostClassifier(random_state=42, eval_metric='Accuracy', task_type='GPU')
    return model

def create_catboost_regressor():
    model = CatBoostRegressor(random_state=42, task_type='GPU')
    return model

def grid_search_params():

    grid = {
        'iterations': [1],
        'depth': [2]
    }

    # grid = {
    #     'iterations': [5000, 10000],
    #     'learning_rate': [0.005, 0.0001],
    #     'depth': [2, 4, 6],
    #     'l2_leaf_reg': [5, 15, 25],
    #     'early_stopping_rounds': [500],
    #     'verbose': [250]
    # }

    return grid
