from xgboost import XGBClassifier, XGBRegressor

def create_xgboost_classifier_binary():
    model = XGBClassifier(objective='binary:logistic', tree_method='gpu_hist', verbosity=0)
    return model

def create_xgboost_classifier_multi():
    model = XGBClassifier(objective='multi:softprob', tree_method='gpu_hist', verbosity=0)
    return model

def create_xgboost_regressor():
    model = XGBRegressor(objective='reg:squarederror', tree_method='gpu_hist', verbosity=0)
    return model

def create_grip_params_xgboost():
    #
    # grid = {
    #     'n_estimators': [10],
    #     'max_depth': [2]
    # }

    grid = {
        'max_depth': [3, 4, 5, 7],
        'learning_rate': [0.005, 0.0001],
        'gamma': [0, 0.25, 1],
        'reg_lambda': [0, 1, 10],
        # 'scale_pos_weight': [1, 3, 5],
        # 'subsample': [0.8],
        # 'colsample_bytree': [0.5],
        'n_estimators': [1000, 2000]
    }

    return grid